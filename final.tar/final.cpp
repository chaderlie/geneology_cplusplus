/***********************************************************************
 * Program:
 *    Final.cpp
 * Author:
 *    Claire Haderlie
 * Summary: 
 *    This program reads in a .ged file. It alphabetizes the inidividuals
 *    in a file and writes them into the sorted.dat file. The families are
 *    then built and the generations are output to the screen.
 ************************************************************************/

#include <iostream>      
#include <string>
#include <fstream>       
#include <string>
#include <cassert>

#include "person.h"       //Include the person class
#include "pedigree.h"     //Include the pedigree 
#include "genNode.h"      //Include the Generation Node
#include "pedIterator.h"  //Include the pedigree iterator

using namespace std;


/************************************************************************
* BUILD FAMILY
* This function takes in a dad's ID, a mom's ID, and a child's ID, and the
* pedigree. It searches through the pedigree to find the dad's, mom's, and
* child's GenNode. It sets the child's pointers to the appropriate family
* member.
*************************************************************************/
void buildFamily(string dad, string mom, string child, Pedigree & pedigree)
{
   //Create iterators to each of the family members
   PedIterator momIt = pedigree.end();
   PedIterator dadIt = pedigree.end();
   PedIterator childIt = pedigree.end();
   
   
   PedIterator it = pedigree.begin();
   
   //Find the GenNodes that have these family members in them
   for(; it != pedigree.end(); it++)
   {
      //Find the mom!
      if((*it).idNum == mom)
      {
         momIt = it;
      }
      
      //Find the dad!
      if((*it).idNum == dad)
      {
         dadIt = it;
      }    
      
      //Find the child!
      if((*it).idNum == child)
      { 
         childIt = it;
      }
   }

   if(childIt.pointer != NULL)
   {
      //Set the childs parental figures to what we found
      childIt.pointer->addMom(momIt.pointer);
      childIt.pointer->addDad(dadIt.pointer);
   }
}

/************************************************************
* READ FILE
* This function opens the file and reads in each line. If it
* is an Individual section, it reads in the person and inserts 
* it into the linked list. If it is a Family section, it gets
* the ID numbers of each member and builds the tree
************************************************************/
void readFile(char filename [], Pedigree & pedigree)
{
   //Open the file
   ifstream fin(filename); 
   
   //If it fails, we cannot do anything
   if(fin.fail())
   {
      cout << "ERROR: unable to open file. Program aborted." << endl;
      return;
   }
   
   //Make a line
   string line;
   bool isNewPerson = false;
   
   //Get the first line
   getline(fin, line);
   
   while(!fin.eof())
   {         
      if(line[0] == '0' && line[3] == 'F')
      { 
         //Make a string for each of the ID numbers       
         string dadID = "";
         string momID = "";
         string childID = "";
         
         while(true)       
         {
            //Get the next line
            getline(fin, line);
            
            if(line[0] == '1')
            {
               //If it is the husband, get his ID
               if(line.substr(2, 4) == "HUSB")
               { 
                  int i = 9;         
                  while(line[i] != '@')
                  { 
                     dadID += line[i];
                     i++;
                  }

                  continue;  
               }
               
               //If it is the wife, get her ID
               else if(line.substr(2, 4) == "WIFE")
               { 
                  int i = 9;         
                  
                  while(line[i] != '@')
                  { 
                     momID += line[i];
                     i++;
                  }
                  
                  continue;
               }
               
               //If it is the child, get his/her ID
               else if(line.substr(2, 4) == "CHIL")
               {
                  int i = 9;         
                  while(line[i] != '@')
                  { 
                     childID += line[i];
                     i++;
                  }
                  
                  //We have a complete family and can break the loop
                  break;
               }
            }
         }
         
         //Build the family!
         buildFamily(dadID, momID, childID, pedigree);
      } 
      
      //If we are at an individual, let's get their info
      else if(line[0] == '0' && line[3] == 'I')
      {
         //Make the new person
         Person person;
         
         //Get their ID number from the line
         int i = 4;         
         while(line[i] != '@')
         { 
            person.idNum += line[i];
            i++;
         } 
         
         //Get the next line
         getline(fin, line);
         
         //If it starts with 0, it's ANOTHER person
         if(line[0] == '0')
         {
            isNewPerson = true;
            continue;
         }
         
         while(true)
         {
            //If the line starts at 0, it's a new person and we can break the loop      
            if(line[0] == '0')
            {
               isNewPerson = true;
               break;
            }
            
            //If it starts with 2, it's a name
            if(line[0] == '2')
            {
               //Get the given names
               if(line.substr(2, 4) == "GIVN")
                  person.givenName = line.substr(7, line.size() - 7);
               
               //Get the surname, if it exists
               else if(line.substr(2, 4) == "SURN")
               {
                  person.lastName = line.substr(7, line.size() - 7);
               }
               
               //Get the next line
               getline(fin, line); 
               continue;
            }
            
            //If it's a birthday, let's store that
            if(line.substr(2, 4) == "BIRT")
            {      
               //Get the date!
               getline(fin, line); 
               
               //If the date exists, let's store it
               if(line.substr(2, 4) == "DATE")
               {
                  person.birthdate = line.substr(7, line.size() - 7);
                  break;
               }
               
               continue;
            }
            
            //Get the next line
            getline(fin, line);     
         }
         
         //Insert the person into the pedigree and make sure it stays alphabetized      
         pedigree.sortAndInsert(person);
      }     
      
      else
      {
         //If we don't have a new person, we can get the next line
         if(!isNewPerson)
            getline(fin, line);

         //Reset the bool
         isNewPerson = false;
         continue;
      }      
   }
   
   //Close the file!
   fin.close(); 
   
   return;
}

/*********************************************************************
 * WRITE FILE
 * This function write the pedigree into the sorted.dat file.
 **********************************************************************/
void writeFile(const Pedigree & pedigree)
{
   //Open the sorted.dat file
   fstream fout("sorted.dat");

   //If it fails, we can't write it out
   if(fout.fail())
   {
      cout << "ERROR: unable to write to file. Program aborted." << endl;
      return;
   }
   
   //Make the iterator to go through the pedigree
   PedIterator it = pedigree.begin();
   
   //Write each person to the file
   for(; it != pedigree.end(); it++)
      fout << *it;
   
   //Close the file
   fout.close();
   
   return;
}

/********************************************************************
* DISPLAY GENERATIONS
* This function finds the first person who was in the GED file and 
* displays their family tree based upon who that is
**********************************************************************/
void displayGenerations(const Pedigree & pedigree)
{
   //Declare an iterator   
   PedIterator pedIt = pedigree.begin();
   
   //Go through the pedigree and find the person whose records are in the pedigree
   for(; pedIt != pedigree.end(); pedIt++)
   {
      //If its the person, display their tree!
      if((*pedIt).idNum == "1")
      {
         pedIt.pointer->displayByLevel();
         break;  //We're done with the loop now.
      }
   }
}

/**********************************************************************
 * MAIN
 * This function runs the above functions to correctly process a
 * .ged file. It accepts the filename from the command line.
 ***********************************************************************/
int main(int argc, char *argv[])
{
   //Make a pedigree (a linked list tree combination)
   Pedigree pedigree;
   
   //Read in the file with the filename received from the command line
   readFile(argv[1], pedigree);
   
   //Write the alphabetized file to the sorted.dat file 
   writeFile(pedigree);
   
   //Display the generations
   displayGenerations(pedigree);
   
   return 0;
}




